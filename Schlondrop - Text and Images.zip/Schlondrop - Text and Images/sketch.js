var img1;
var img2;
var img3;
var img4;
var img5;
var img6;
var imgB;
var textO;
var rectX = 0;
var changeCount = 0;
var changeMode = 0;
var changeLoc = 0;

function preload() {
  img1 = loadImage('assets/haus_1.png');
  imgB = loadImage('assets/backdrop.png');
  img2 = loadImage('assets/hausT_1.png');
  img3 = loadImage('assets/hausT_2.png');
  img4 = loadImage('assets/hausT_3.png');
  img5 = loadImage('assets/hausT_4.png');
  img6 = loadImage('assets/hausT_5.png');
}

function setup() {
  createCanvas(500, 400);
  colorMode(RGB, 255, 255, 255, 255);
  textFont('Verdana');
}
  
function draw() {
  noStroke();
    if (changeCount == 0) {
      image(imgB, 0, -10);
      if (changeLoc == 0) {
        text0 = '';
        rectX = 0;
        if (changeMode == 0) {
          image(img1, 0, 125);
          changeMode = 1;
        } else {
          image(img2, 0, 125);
          changeMode = 0;
        }
      } else if (changeLoc == 1) {
        text0 = 'Do you believe in-';
        rectX = 192.5;
        if (changeMode == 0) {
          image(img3, 0, 125);
          changeMode = 1;
        } else {
          image(img4, 0, 125);
          changeMode = 0;
        }
      } else {
        text0 = 'sin?';
        rectX = 47.5;
        if (changeMode == 0) {
          image(img5, 0, 125);
          changeMode = 1;
        } else {
          image(img6, 0, 125);
          changeMode = 0;
        }
      }
    }
    changeCount++;
    if (changeCount > 20) {
      changeCount = 0;
    }
    if (mouseY > 266) {
      changeLoc = 2;
    } else if (mouseY > 133) {
      changeLoc = 1;
    } else {
      changeLoc = 0;
    }
    
    if(changeCount == 1) {
      fill(56, 69, 88);
      rect(mouseX - (rectX / 2), mouseY, rectX, 25, 10);
      fill(250, 250, 195);
      textSize(20);
      text(text0, mouseX + 5 - (rectX / 2), mouseY + 20);
    }

    fill(102, 74, 62);
    beginShape();
    vertex(0, 0);
    vertex(500, 0);
    vertex(500, 400);
    vertex(0, 400);
    beginContour();
    vertex(25, 25);
    vertex(25, 375);
    vertex(475, 375);
    vertex(475, 25);
    endContour();
    endShape(CLOSE);
    beginShape();
    vertex(25, 25);
    vertex(50, 25);
    vertex(38, 30);
    vertex(30, 38);
    vertex(25, 50);
    vertex(25, 25);
    endShape();
    beginShape();
    vertex(475, 25);
    vertex(450, 25);
    vertex(462, 30);
    vertex(470, 38);
    vertex(475, 50);
    vertex(475, 25);
    endShape();
    beginShape();
    vertex(475, 375);
    vertex(475, 350);
    vertex(470, 362);
    vertex(462, 370);
    vertex(450, 375);
    vertex(475, 375);
    endShape();
    beginShape();
    vertex(25, 375);
    vertex(25, 350);
    vertex(30, 362);
    vertex(38, 370);
    vertex(50, 375);
    vertex(25, 375);
    endShape();
    /*
    fill(148, 79, 56);
    beginShape();
    vertex(0, 0);
    vertex(500, 0);
    vertex(500, 400);
    vertex(0, 400);
    beginContour();
    vertex(10, 10);
    vertex(5, 395);
    vertex(490, 390);
    vertex(495, 5);
    endContour();
    endShape(CLOSE);
    */
}