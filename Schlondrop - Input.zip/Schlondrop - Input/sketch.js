let x = 255;
let y = 255;
let xB = 20;
let yB = 20;
let xS = 0;
let yS = 0;
let mouseB = 0;
let opa = 255;
function setup() {
  createCanvas(510, 510);
  colorMode(RGB, 255, 255, 255, 255);
  background(255, 225, 220);
  noStroke();
  fill(0, 0, 0, 0);
}

function draw() {
  if (mouseIsPressed) {
    mouseB = (mouseX + mouseY) / 4;
  }
  if (-2.5 < xS && xS < 2.5 && -2.5 < yS && yS < 2.5) {
    background(255, 225, 220);
    if (opa < 255) {
      opa += 2;
    }
    fill(x / 2, y / 2, mouseB, 255);
  } else {
    if (opa > 25) {
      opa -= 2;
    }
    fill(x / 2, y / 2, mouseB, opa);
  }
  ellipse(x, y, xB, yB);
  if (keyIsPressed) {
  	if (key == 'a') {
      if (xS > -3) {
        xS -= 0.1;
      }
      xB += 0.5;
  	} 
    else if ( key == 'd') {
  	  if (xS < 3) {
        xS += 0.1;
      }
      xB += 0.5;
  	} else if (key == 'w') {
  	  if (yS > -3) {
        yS -= 0.1;
      }
      yB += 0.5;
  	} 
    else if ( key == 's') {
  	  if (yS < 3) {
        yS += 0.1;
      }
      yB += 0.5;
  	}
  } else {
    if (xS < 0) {
      xS += 0.1;
    }
    if (xS > 0) {
      xS -= 0.1;
    }
    if (yS < 0) {
      yS += 0.1;
    }
    if (yS > 0) {
      yS -= 0.1;
    }
    if (xB > 20) {
      xB -= 1;
    }
    if (yB > 20) {
      yB -= 1;
    }
    /*if (-1 < xS && xS < 1) {
      xS = 0;
    }
    if (-1 < yS && yS < 1) {
      yS = 0;
    }*/
  }
  x += xS;
  y += yS;
  if (x < 5) {
    x -= xS;
  } else if (x > 505) {
    x -= xS;
  }
  if (y < 5) {
    y -= yS;
  } else if (y > 505) {
    y -= yS;
  }
}