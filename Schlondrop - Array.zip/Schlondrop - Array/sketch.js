let store = [];
let back = [];
let dec = [];
let front = [];
let move1 = [];
let move2 = [];
let moveVal = 250;
let mX = 250;
let dest;
let direc = "left";
let change = true;
let wormSize = 25;
function setup() {
  colorMode(RGB, 255, 255, 255, 255);
  createCanvas(500, 400);
  for (let i = 0; i < 3; i++) {
    append(store, random(50, 205));
  }
  append(back, store[0] + random(-50, 50));
  for (let i = 1; i < 3; i++) {
    append(back, store[i] + random(-50, 50));
  }
  append(dec, store[0] + random(-50, 50));
  append(dec, store[1]);
  append(dec, store[2] + random(-50, 50));
  for (let i = 0; i < 2; i++) {
    append(front, store[i] + random(-50, 50));
  }
  append(front, store[2] + random(-50, 50));
  background(dec[0], dec[1], dec[2]);
  
  noStroke();
  fill(back[0], back[1], back[2]);
  ellipse(250, 150, 400, 600);
  fill(back[0], back[1] + random(-50, 50), back[2] + random(-50, 50));
  ellipse(80, 75, 40, 25);
  ellipse(95, 65, 35, 35);
  ellipse(105, 75, 40, 30);
  ellipse(265, 70, 55, 45);
  ellipse(290, 55, 55, 55);
  ellipse(315, 70, 55, 40);
  fill(dec[0] + random(-50, 50), dec[1] + random(-50, 50), dec[2]);
  ellipse(250, 0, 600, 100);
  
  fill(front[0], front[1], front[2]);
  rect(0, 250, width, 150);
  fill(front[0] - 25, front[1] - 25, front[2]);
  ellipse(400, 390, 380, 250);
  fill(front[0] - 35, front[1] - 35, front[2] - 5);
  ellipse(100, 390, 400, 200);
  
  append(move1, moveVal);
  for (let i = 0; i < 4; i++) {
    moveVal -= random(0, 50);
    append(move1, moveVal);
  }
  moveVal = 250;
  for (let i = 0; i < 5; i++) {
    moveVal += random(0, 50);
    append(move2, moveVal);
  }
  print(move1);
  print(move2);
}

function draw() {
  fill(dec[0] + random(-25, 25), dec[1], dec[2] + random(-25, 25));
  if (change == true) {
    if (direc == "left") {
      dest = random(move2);
      direc = "right";
    } else {
      dest = random(move1);
      direc = "left";
    }
    change = false;
  } else {
    if (direc == "left") {
      if (mX >= dest) {
        mX -= 2;
        ellipse(mX, mouseY, wormSize, wormSize);
      } else {
        change = true;
      }
    } else {
      if (mX <= dest) {
        mX += 2;
        ellipse(mX, mouseY, wormSize, wormSize);
      } else {
        change = true;
      }
    }
  }
}